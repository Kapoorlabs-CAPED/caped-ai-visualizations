# caped-ai-visualizations
Visualization library for bounding boxes, activation maps and napari widgets for oneat visualization
